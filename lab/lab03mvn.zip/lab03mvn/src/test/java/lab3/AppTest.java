package lab3;


import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

    @Test
    public void noTest() {}
}
